package com.example.topquizz;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Déclaration des variables
    TextView totalQuestionsTextView;
    TextView questionsTextView;
    Button ansA, ansB, ansC, ansD;
    Button submitBtn;

    // Le score actuelle
    int score = 0;
    // Le nombre total de question
    int totalQuestion = QuestionAnswer.question.length;
    // La question actuelle
    int currentQuestionIndex = 0;
    // La réponse sélectionner
    String selectedAnswer = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Attribution des variables à leurs éléments correspondant
        totalQuestionsTextView = findViewById(R.id.total_question);
        questionsTextView = findViewById(R.id.question);
        ansA = findViewById(R.id.ans_A);
        ansB = findViewById(R.id.ans_B);
        ansC = findViewById(R.id.ans_C);
        ansD = findViewById(R.id.ans_D);
        submitBtn = findViewById(R.id.submit_btn);

        //Ajoute un ecouteur sur les éléments suivants (si clique sur le bouton alors appelle la méthode onClick)
        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        // Modifie le champ de texte
        totalQuestionsTextView.setText("Total question : " + totalQuestion);

        // appelle la methode qui affiche une nouvelle question avec ses réponses
        loadNewQuestion();

    }

    @Override
    // méthode qui s'active si l'utilisateur clique sur un bouton
    public void onClick(View view) {

        Button clickedButton = (Button) view;
        // Rénitialise la couleur du bouton réponse(X) en blanc si l'utilisateur sélectionne une autre réponse
        ansA.setBackgroundColor(Color.WHITE);
        ansB.setBackgroundColor(Color.WHITE);
        ansC.setBackgroundColor(Color.WHITE);
        ansD.setBackgroundColor(Color.WHITE);


        // si bouton submit cliqué
        if (clickedButton.getId()==R.id.submit_btn){
            // Si reponse selectionner est la bonne incrémente le score
            if (selectedAnswer.equals(QuestionAnswer.correctAnswers[currentQuestionIndex])){
                score++;
            }
            // increment l'index
            currentQuestionIndex++;
            // Charge une nouvelle question
            loadNewQuestion();


        // Sinon clique sur un bouton autre que submit
        }else {
            // transfère la réponse dans la variable et change la couleur du bouton selectionner
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);
        }
    }


    // Méthode qui charge une nouvelle question
    void loadNewQuestion(){

        // Si a repondu a toutes les questions
        if (currentQuestionIndex == totalQuestion){
            // Termine le quiz
            finishQuiz();
            return;
        }
        // Change le texte dans le bloc question avec la question actuelle
        questionsTextView.setText(QuestionAnswer.question[currentQuestionIndex]);
        // Change le texte de la réponse A avec la question actuelle et la réponse 1
        ansA.setText(QuestionAnswer.choices[currentQuestionIndex][0]);
        // Change le texte de la réponse B avec la question actuelle et la réponse 2
        ansB.setText(QuestionAnswer.choices[currentQuestionIndex][1]);
        // Change le texte de la réponse C avec la question actuelle et la réponse 3
        ansC.setText(QuestionAnswer.choices[currentQuestionIndex][2]);
        // Change le texte de la réponse D avec la question actuelle et la réponse 4
        ansD.setText(QuestionAnswer.choices[currentQuestionIndex][3]);
    }

    // Méthode fin quizz
    void finishQuiz(){
        String passStatus = "";
        // Si le score et supérieur a 60% du total des questions
        if (score > totalQuestion*0.60){
            passStatus = "Passed";
        }else{
            passStatus = "Failed";
        }

        // Affiche une fenetre avec le score de l'utilisateur a la fin du quiz
        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score is " + score + " out of " + totalQuestion)
                .setPositiveButton("Restart", (dialogInterface, i) -> restartQuiz())
                .setCancelable(false)
                .show();
    }

    // Methode qui permet de revenir a zero a la fin du quiz
    void restartQuiz(){
        score = 0;
        currentQuestionIndex = 0;
        loadNewQuestion();
    }
}