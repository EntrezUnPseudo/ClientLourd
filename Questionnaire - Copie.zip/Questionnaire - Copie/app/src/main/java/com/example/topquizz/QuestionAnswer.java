package com.example.topquizz;

public class QuestionAnswer {

    // Tableau contenant les questions
    public static String question[] ={
        "Quel est le language pour modifier le contenu d'un site internet?",
            "Quel est le language utilisé par AndroidStudio?",
                "Lequel de ces languages est utilisé pour creer des jeux vidéo sur Unity?"
    };
    // Tableau contenant les choix
    public static String choices[][] ={
            {"C#","Javascript","HTML","Java"},
            {"Java","Css","Python","PHP"},
            {"PHP","Javasript","C#","Java"}
    };
    // Tableau contenant les réponses
    public static String correctAnswers[] ={
            "HTML",
            "Java",
            "C#"
    };

}
